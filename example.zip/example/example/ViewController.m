//
//  ViewController.m
//  testjason
//
//  Created by Riko Ghanem on 17/12/15.
//  Copyright © 2015 Riko Ghanem. All rights reserved.
//

#import "ViewController.h"


#import "get_server.h"


@interface ViewController ()<get_serverDelegate>{
    
    get_server * connection;
    
}

@end

@implementation ViewController



- (void) get_server_finished:(NSString*)output error:(NSInteger)code{
    
    
    if (code == 1) {
        
        //succeed
        
        NSLog(@"%@",output);
        
    }else{
        
        switch (code) {
            case -1:
                NSLog(@"Source protocol not supported");
                break;
                
            case -2:
                //domain fail
                NSLog(@"%@",output);
                break;
                
            case -3:
                //404 error
                NSLog(@"%@",output);
                break;
                
            case -4:
                // timeout
                NSLog(@"%@",output);
                break;
                
            default:
                break;
        }
        
    }
    
    NSLog(@"Fetching data done...\n\n\n");
}


- (void)viewDidLoad {
    
    
    [super viewDidLoad];
    
    
    
    connection = [get_server new];
    
    connection.delegate =self;
    
    [connection send_request: [NSString stringWithFormat:@"https://video.worldcdn.net/539462004/%@.jsonp?callback=MyCallBack", @"streamname"] type:@"rtmp" timeout:1.5];
    
    
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    
}

@end
