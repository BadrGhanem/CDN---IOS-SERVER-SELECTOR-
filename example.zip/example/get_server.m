//
//  get_server.m
//  testjason
//
//  Created by Riko Ghanem on 17/12/15.
//  Copyright © 2015 Riko Ghanem. All rights reserved.
//

#import "get_server.h"

@implementation get_server{
    
    NSString * protocol;
    
    NSString * callback;
    
    NSInteger error_code;
    
}

@synthesize responseData = _responseData;



- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    
    
   // for 404 "Not Found" or 500 "Internal Server Error" should able to capture inside didReceiveResponse method
    
    if ([response respondsToSelector:@selector(statusCode)])
    {
        NSInteger statusCode = [((NSHTTPURLResponse *)response) statusCode];
        if (statusCode == 404)
        {
            
            error_code = -3;
            
            if ([self.delegate respondsToSelector:@selector(get_server_finished:error:)]) {
                
                [self.delegate get_server_finished:[NSString stringWithFormat:@"didReceiveResponse statusCode with %li", (long)statusCode] error:error_code];
                
            }
            
            [connection cancel];  // stop connecting; no more delegate messages
        
        

        }
    }
    
       [self.responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [self.responseData appendData:data];
}



//timeout is received in this method also

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    

    if (error.code == NSURLErrorTimedOut) {
        
            error_code = -4;
    }else{
        
            error_code = -2;
    }
    

   
    if ([self.delegate respondsToSelector:@selector(get_server_finished:error:)]) {
        
        [self.delegate get_server_finished:[NSString stringWithFormat:@"Connection failed: %@ %@",  [error localizedDescription],   [[error userInfo] objectForKey:NSURLErrorFailingURLStringErrorKey]] error:error_code];
        
    }

    

}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {

    
    
    NSString *responseString = [[NSString alloc] initWithData:self.responseData encoding:NSUTF8StringEncoding];
    NSString * str= responseString;
 
    

    str = [str stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@(",callback] withString:@""];
    str = [str stringByReplacingOccurrencesOfString:@");" withString:@""];
    NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *ec = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
    

    if (ec[[protocol lowercaseString]] ==NULL) {
        
        error_code = -1;
        
    }else{
        
        error_code = 1;

    }
  

    
    
    
    if ([self.delegate respondsToSelector:@selector(get_server_finished:error:)]) {
        
        [self.delegate get_server_finished:ec[[protocol lowercaseString]] error:error_code];

    }
    
}



- (void)send_request:(NSString*)url type:(NSString*)type timeout:(double)max{
    

    
    error_code = -100;
    
    protocol = type;
    
    NSArray *url_callback_array = [url componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"="]];
    
    
    if (url_callback_array.count > 1) {
        
          callback = [url_callback_array objectAtIndex:1];
    }
    


    
    self.responseData = [NSMutableData data];
    
    
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]
                                              cachePolicy:NSURLRequestUseProtocolCachePolicy
                                          timeoutInterval:max];
    

    


#if  __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_6_0    &&  __IPHONE_OS_VERSION_MIN_REQUIRED   <  __IPHONE_9_0
    
    
    #ifdef DEBUG
    NSLog(@"IOS under 9\n");
    #endif
    
    (void)[[NSURLConnection alloc] initWithRequest:request delegate:self];
    
    
    #else 
    
    #ifdef DEBUG
    NSLog(@"IOS 9 or over\n");
    #endif
    
    
    NSURLSession *session = [NSURLSession sharedSession];
    
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:
                                      request completionHandler:
                                      ^(NSData *data, NSURLResponse *response, NSError *error) {
                                          
                                          
                                          
                                          NSInteger statusCode = [((NSHTTPURLResponse *)response) statusCode];
                                          
                                          if (data) {
                                              
                                              NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                              
                                              
                                              NSString * str= responseString;
                                              
                                              
                                              
                                              str = [str stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@(",callback] withString:@""];
                                              str = [str stringByReplacingOccurrencesOfString:@");" withString:@""];
                                              NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding];
                                              NSDictionary *ec = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
                                              
                                              
                                              if (ec[[protocol lowercaseString]] ==NULL) {
                                                  
                                                  error_code = -1;
                                                  
                                              }else{
                                                  
                                                  error_code = 1;
                                                  
                                              }
                                              
                                              
                                              
                                              
                                              
                                              if ([self.delegate respondsToSelector:@selector(get_server_finished:error:)]) {
                                                  
                                                  [self.delegate get_server_finished:ec[[protocol lowercaseString]] error:error_code];
                                                  
                                              }
                                              
                                              
                                              
                                              
                                              
                                          }else{
                                              
                                              if (statusCode == 404) {
                                                  
                                                  
                                                  error_code = -3;
                                                  
                                                  if ([self.delegate respondsToSelector:@selector(get_server_finished:error:)]) {
                                                      
                                                      [self.delegate get_server_finished:[NSString stringWithFormat:@"didReceiveResponse statusCode with %li", (long)statusCode] error:error_code];
                                                      
                                                  }
                                                  
                                                  
                                                  
                                                  
                                              }else if(error.code == NSURLErrorTimedOut){
                                                  
                                                  error_code = -4;
                                                  
                                                  if ([self.delegate respondsToSelector:@selector(get_server_finished:error:)]) {
                                                      
                                                      [self.delegate get_server_finished:[NSString stringWithFormat:@"Connection failed: %@ %@",  [error localizedDescription],   [[error userInfo] objectForKey:NSURLErrorFailingURLStringErrorKey]] error:error_code];
                                                      
                                                  }
                                                  
                                                  
                                              }else{
                                                  
                                                  error_code = -2;
                                                  
                                                  
                                                  if ([self.delegate respondsToSelector:@selector(get_server_finished:error:)]) {
                                                      
                                                      [self.delegate get_server_finished:[NSString stringWithFormat:@"Connection failed: %@ %@",  [error localizedDescription],   [[error userInfo] objectForKey:NSURLErrorFailingURLStringErrorKey]] error:error_code];
                                                      
                                                  }
                                                  
                                                  
                                                  
                                              }
                                          }
                                          
                                          
                                          
                                          [session invalidateAndCancel];
                                          
                                          
                                      }];
    
    [dataTask resume];
    

#endif
    
 
    

    
}



@end
