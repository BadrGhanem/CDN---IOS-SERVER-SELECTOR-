//
//  get_server.h
//  testjason
//
//  Created by Riko Ghanem on 17/12/15.
//  Copyright © 2015 Riko Ghanem. All rights reserved.
//

#import <Foundation/Foundation.h>


@protocol get_serverDelegate;

@interface get_server : NSObject

@property (nonatomic, strong) NSMutableData *responseData;

- (void)send_request:(NSString*)url type:(NSString*)type timeout:(double)max;

@property (nonatomic, weak) id<get_serverDelegate> delegate;

@end




@protocol get_serverDelegate <NSObject>

@optional


- (void) get_server_finished:(NSString*)output error:(NSInteger)code;


@end